sh run_large.sh 1 2>&1 |tee output
