/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2019, Linaro Limited
 *
 */

#ifndef STATS_H
#define STATS_H

int stats_runner_cmd_parser(int argc, char *argv[]);

#endif /*STATS_H*/
