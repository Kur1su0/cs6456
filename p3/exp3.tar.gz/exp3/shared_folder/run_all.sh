sh run.sh 100 2>&1 |tee output
