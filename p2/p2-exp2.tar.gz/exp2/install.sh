# scp \
lab2_list-steal \
lab2_list-malloc \
lab2_list-biglock \
lab2_list-steal2-naivepadding \
lab2_list-steal-padding \
*.sh \
makalu:/tmp/lab2b/
 
rsync -avxP \
list \
list-m \
list-p \
list-pm \
list-pml \
list-pmla \
*.sh \
makalu:/tmp/lab2b/
 
