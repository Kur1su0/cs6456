./counter --iterations=100000 --threads=40 
./counter --iterations=100000 --threads=40 --sync=m
./counter --iterations=100000 --threads=40 --sync=s
./counter --iterations=100000 --threads=40 --sync=c 
